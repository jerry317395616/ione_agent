# 童健云智能助手 2.1.1

基于已经验证可用的 2.1.0 恢复版，仅增加两个精确隐藏目标。

## Logo

只隐藏：

`img.logo-img[alt="logo"]`

且要求 `src` 包含 `qwen-logo.svg`。

## 模型选择区

只隐藏同时满足全部条件的元素：

- `div.wms-trigger__content`
- 直接子元素 `div.wms-trigger__text`
- 文本严格等于 `Qwen3.8-Max`
- 直接子元素 `span.wms-trigger__icon`
- 元素位于页面顶部模型区域

只隐藏该 `.wms-trigger__content` 自身，不隐藏父容器。

## SPA 兼容

Qwen 动态挂载新节点时，只检查新增加的节点及其后代是否为上述两个精确目标。
不会按公共 class 全局隐藏聊天界面。

保留 2.1.0 对旧版 data-ione-* 副作用的恢复逻辑。
