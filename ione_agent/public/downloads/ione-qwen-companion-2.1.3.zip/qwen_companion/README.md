# 童健云智能助手 2.1.3

2.1.3 修复 Qwen 模型文本分阶段写入时 2.1.2 仍可能漏掉的问题。

## 精确匹配

模型区仍然必须同时满足：

- `div.wms-trigger__content`
- 直接子元素 `div.wms-trigger__text`
- 文本严格等于 `Qwen3.8-Max`
- 直接子元素 `span.wms-trigger__icon`

命中后只给该元素增加：

`data-ione-v213-model-hidden="1"`

CSS 只隐藏带这个专用标记的模型区，不隐藏其它 `.wms-trigger__content`。

## SPA 时机修复

- 监听新增元素节点。
- 监听新增文本节点。
- 监听 `characterData` 文本变化。
- 如果 Qwen 先创建外层、后写入 `Qwen3.8-Max`，也会重新检查所在模型容器。

Logo 仍只匹配真实 `qwen-logo.svg`。
保留 2.1.0 的旧版副作用恢复逻辑。
