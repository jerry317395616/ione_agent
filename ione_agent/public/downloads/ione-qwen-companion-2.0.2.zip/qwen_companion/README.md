# 童健云智能助手浏览器扩展 2.0.2

2.0.2 修复 2.0.1 的模型区域误隐藏问题。

## 精确规则

Logo 只匹配真实元素：

`img.logo-img[alt="logo"]`

并要求 `src` 包含 `qwen-logo.svg`。

模型区只匹配同时满足以下条件的元素：

- `div.wms-trigger__content`
- 直接子元素 `div.wms-trigger__text`
- 文本严格等于 `Qwen3.8-Max`
- 直接子元素 `span.wms-trigger__icon`
- 位于页面顶部模型栏范围

## 安全修复

- 删除 2.0.1 的全局 `.wms-trigger__content { visibility:hidden }`。
- 不隐藏任何父容器。
- 不使用 MutationObserver。
- 不使用长期 setInterval。
- 只在页面初始加载后的 0 / 0.3 / 1.2 / 3 秒做精确匹配。
- 启动时恢复旧版本写入元素的 display / visibility / opacity / pointer-events。

升级时仍建议在 `edge://extensions/` 中只保留一个“童健云智能助手”实例。
