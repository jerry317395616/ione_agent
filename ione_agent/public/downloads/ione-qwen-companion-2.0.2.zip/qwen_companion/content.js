(() => {
  "use strict";

  const HOST_ID = "ione-qwen-companion-v2";
  const SITE_ORIGIN = "https://child.myyr.top";
  const VERSION = "2.0.2";
  const TARGET_MODEL = "Qwen3.8-Max";

  function normalize(value) {
    return (value || "")
      .replace(/\s+/g, " ")
      .replace(/[\u200b-\u200d\ufeff]/g, "")
      .trim();
  }

  function cleanupLegacyCustomization() {
    document.getElementById("ione-qwen-brand-mask")?.remove();
    document.getElementById("ione-qwen-companion")?.remove();
    document.getElementById(HOST_ID)?.remove();

    document
      .querySelectorAll(
        "[data-ione-hidden], [data-ione-safe-hidden], [data-ione-v2-model-button], [data-ione-model-hidden], [data-ione-v202-hidden]"
      )
      .forEach((element) => {
        if (!(element instanceof HTMLElement || element instanceof SVGElement)) return;

        element.style.removeProperty("display");
        element.style.removeProperty("visibility");
        element.style.removeProperty("opacity");
        element.style.removeProperty("pointer-events");

        element.removeAttribute("data-ione-hidden");
        element.removeAttribute("data-ione-safe-hidden");
        element.removeAttribute("data-ione-v2-model-button");
        element.removeAttribute("data-ione-model-hidden");
        element.removeAttribute("data-ione-v202-hidden");
      });
  }

  function hideExactQwenLogo() {
    let hidden = 0;

    document
      .querySelectorAll('img.logo-img[alt="logo"]')
      .forEach((logo) => {
        if (!(logo instanceof HTMLImageElement)) return;

        const rawSrc = logo.getAttribute("src") || "";
        const resolvedSrc = logo.src || "";
        if (
          !rawSrc.includes("qwen-logo.svg") &&
          !resolvedSrc.includes("qwen-logo.svg")
        ) {
          return;
        }

        logo.style.setProperty("visibility", "hidden", "important");
        logo.style.setProperty("opacity", "0", "important");
        logo.style.setProperty("pointer-events", "none", "important");
        logo.setAttribute("data-ione-v202-hidden", "qwen-logo");
        hidden += 1;
      });

    return hidden;
  }

  function hideExactModelSelector() {
    const triggers = document.querySelectorAll("div.wms-trigger__content");

    for (const trigger of triggers) {
      if (!(trigger instanceof HTMLElement)) continue;

      const textNode = trigger.querySelector(":scope > div.wms-trigger__text");
      const iconNode = trigger.querySelector(":scope > span.wms-trigger__icon");

      if (!(textNode instanceof HTMLElement)) continue;
      if (!(iconNode instanceof HTMLElement)) continue;
      if (normalize(textNode.textContent) !== TARGET_MODEL) continue;

      const rect = trigger.getBoundingClientRect();
      if (
        rect.width <= 0 ||
        rect.height <= 0 ||
        rect.width > 360 ||
        rect.height > 100 ||
        rect.top < -5 ||
        rect.top > 130 ||
        rect.left < 120 ||
        rect.left > 900
      ) {
        continue;
      }

      trigger.style.setProperty("visibility", "hidden", "important");
      trigger.style.setProperty("opacity", "0", "important");
      trigger.style.setProperty("pointer-events", "none", "important");
      trigger.setAttribute("data-ione-v202-hidden", "model-selector");
      return true;
    }

    return false;
  }

  function customizePromptPlaceholderOnce() {
    document
      .querySelectorAll("textarea, input, [contenteditable='true']")
      .forEach((control) => {
        if (!(control instanceof HTMLElement)) return;

        const placeholder = normalize(control.getAttribute("placeholder"));
        if (placeholder.toLowerCase().includes("qwen")) {
          control.setAttribute("placeholder", "询问智能助手");
        }
      });
  }

  function applyExactBranding() {
    hideExactQwenLogo();
    hideExactModelSelector();
    customizePromptPlaceholderOnce();
  }

  function link(label, href, sameTab = false) {
    const node = document.createElement("a");
    node.textContent = label;
    node.href = href;
    node.target = sameTab ? "_self" : "_blank";
    node.rel = "noopener noreferrer";
    node.className = "ione-link";
    return node;
  }

  function mountToolbar() {
    const host = document.createElement("div");
    host.id = HOST_ID;
    const shadow = host.attachShadow({ mode: "open" });

    const style = document.createElement("style");
    style.textContent = `
      :host {
        all: initial;
        position: fixed;
        top: 10px;
        left: 50%;
        transform: translateX(-50%);
        z-index: 2147483646;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "PingFang SC",
          "Microsoft YaHei", sans-serif;
      }
      .bar {
        display: flex;
        align-items: center;
        gap: 8px;
        padding: 7px 9px;
        border: 1px solid rgba(15, 118, 110, .18);
        border-radius: 14px;
        background: rgba(255, 255, 255, .92);
        box-shadow: 0 8px 28px rgba(15, 23, 42, .12);
        backdrop-filter: blur(14px);
        -webkit-backdrop-filter: blur(14px);
        color: #0f172a;
        white-space: nowrap;
      }
      .brand {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 0 4px;
        font-size: 13px;
        font-weight: 700;
      }
      .dot {
        width: 9px;
        height: 9px;
        border-radius: 999px;
        background: #14b8a6;
        box-shadow: 0 0 0 4px rgba(20, 184, 166, .12);
      }
      .version {
        padding: 2px 5px;
        border-radius: 6px;
        background: #f1f5f9;
        color: #64748b;
        font-size: 10px;
        font-weight: 700;
      }
      .ione-link, button {
        appearance: none;
        border: 0;
        border-radius: 9px;
        padding: 6px 9px;
        background: #f0fdfa;
        color: #0f766e;
        font: inherit;
        font-size: 12px;
        font-weight: 600;
        text-decoration: none;
        cursor: pointer;
      }
      .ione-link:hover, button:hover {
        background: #ccfbf1;
      }
      @media (prefers-color-scheme: dark) {
        .bar {
          background: rgba(15, 23, 42, .90);
          border-color: rgba(45, 212, 191, .22);
          color: #f8fafc;
        }
        .version {
          background: rgba(148, 163, 184, .14);
          color: #cbd5e1;
        }
      }
    `;

    const bar = document.createElement("nav");
    bar.className = "bar";

    const brand = document.createElement("span");
    brand.className = "brand";
    brand.innerHTML =
      '<span class="dot"></span><span>童健云 · 智能助手</span>' +
      '<span class="version">v2.0.2</span>';

    const home = link("返回童健云", `${SITE_ORIGIN}/desk`, true);
    const cockpit = link("园长驾驶舱", `${SITE_ORIGIN}/app/director-dashboard`);

    const refresh = document.createElement("button");
    refresh.type = "button";
    refresh.textContent = "刷新页面";
    refresh.addEventListener("click", () => window.location.reload());

    bar.append(brand, home, cockpit, refresh);
    shadow.append(style, bar);
    document.documentElement.appendChild(host);
  }

  cleanupLegacyCustomization();
  document.title = "童健云 · 智能助手";
  mountToolbar();
  applyExactBranding();

  // Short hydration retries only. No global class hiding, no observer,
  // and no long-running polling of the chat interface.
  window.setTimeout(applyExactBranding, 300);
  window.setTimeout(applyExactBranding, 1200);
  window.setTimeout(applyExactBranding, 3000);

  void VERSION;
})();
