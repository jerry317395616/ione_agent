(() => {
  "use strict";

  const HOST_ID = "ione-qwen-companion";
  const SITE_ORIGIN = "https://child.myyr.top";
  const COMPACT_KEY = "ione_qwen_companion_compact";
  const BRAND_TITLE = "童健云 · 智能助手";
  const TARGET_MODEL = "qwen3-8-max";
  const HIDDEN_ATTR = "data-ione-safe-hidden";
  const BRAND_MASK_ID = "ione-qwen-brand-mask";

  function normalizeText(value) {
    return (value || "")
      .replace(/\s+/g, " ")
      .replace(/[\u200b-\u200d\ufeff]/g, "")
      .trim();
  }

  function setPageTitle() {
    if (document.title !== BRAND_TITLE) {
      document.title = BRAND_TITLE;
    }
  }

  function isVisible(element) {
    if (!(element instanceof HTMLElement)) return false;
    const rect = element.getBoundingClientRect();
    const style = window.getComputedStyle(element);
    return (
      rect.width > 0 &&
      rect.height > 0 &&
      style.display !== "none" &&
      style.visibility !== "hidden"
    );
  }

  function restoreLegacyHiddenNodes() {
    document.querySelectorAll("[data-ione-hidden]").forEach((element) => {
      if (!(element instanceof HTMLElement)) return;
      element.style.removeProperty("display");
      element.removeAttribute("data-ione-hidden");
    });
  }

  function safelyHide(element, reason) {
    if (!(element instanceof HTMLElement)) return false;

    const rect = element.getBoundingClientRect();
    if (
      rect.width <= 0 ||
      rect.height <= 0 ||
      rect.width > 420 ||
      rect.height > 100
    ) {
      return false;
    }

    element.style.setProperty("visibility", "hidden", "important");
    element.style.setProperty("pointer-events", "none", "important");
    element.setAttribute(HIDDEN_ATTR, reason);
    return true;
  }

  function resetSafeHiddenNodes() {
    document.querySelectorAll(`[${HIDDEN_ATTR}]`).forEach((element) => {
      if (!(element instanceof HTMLElement)) return;
      element.style.removeProperty("visibility");
      element.style.removeProperty("pointer-events");
      element.removeAttribute(HIDDEN_ATTR);
    });
  }

  function isTargetModelText(text) {
    return normalizeText(text)
      .toLowerCase()
      .replace(/\s+/g, "")
      .replace(/[._]/g, "-")
      .includes(TARGET_MODEL);
  }

  function hideTargetModelSelector() {
    const candidates = document.querySelectorAll("button, [role='button']");

    for (const node of candidates) {
      if (!(node instanceof HTMLElement) || !isVisible(node)) continue;

      const rect = node.getBoundingClientRect();
      if (
        rect.top < -5 ||
        rect.top > 110 ||
        rect.left < 180 ||
        rect.left > 760 ||
        rect.width > 360 ||
        rect.height > 90
      ) {
        continue;
      }

      const text = normalizeText(node.textContent);
      if (!isTargetModelText(text)) continue;

      safelyHide(node, "target-model-selector");
      return true;
    }

    return false;
  }

  function findSidebarBackgroundColor() {
    const samplePoints = [
      [150, 24],
      [120, 40],
      [80, 52],
    ];

    for (const [x, y] of samplePoints) {
      let element = document.elementFromPoint(x, y);
      for (let depth = 0; element instanceof HTMLElement && depth < 6; depth += 1) {
        const color = window.getComputedStyle(element).backgroundColor;
        if (
          color &&
          color !== "transparent" &&
          color !== "rgba(0, 0, 0, 0)"
        ) {
          return color;
        }
        element = element.parentElement;
      }
    }

    return "rgb(247, 248, 250)";
  }

  function mountBrandMask() {
    let mask = document.getElementById(BRAND_MASK_ID);

    if (!mask) {
      mask = document.createElement("div");
      mask.id = BRAND_MASK_ID;
      mask.setAttribute("aria-hidden", "true");
      Object.assign(mask.style, {
        position: "fixed",
        top: "0",
        left: "0",
        width: "150px",
        height: "58px",
        zIndex: "2147483645",
        pointerEvents: "none",
      });
      document.documentElement.appendChild(mask);
    }

    mask.style.setProperty("background", findSidebarBackgroundColor(), "important");
    return mask;
  }

  function hideTopLeftBrandGraphicLeaves() {
    const candidates = document.querySelectorAll("svg, img, [role='img'], *");
    let hidden = false;

    for (const candidate of candidates) {
      if (!(candidate instanceof HTMLElement || candidate instanceof SVGElement)) continue;

      const rect = candidate.getBoundingClientRect();
      if (
        rect.width <= 0 ||
        rect.height <= 0 ||
        rect.left < -5 ||
        rect.left > 160 ||
        rect.top < -5 ||
        rect.top > 60 ||
        rect.width > 150 ||
        rect.height > 55
      ) {
        continue;
      }

      const style = window.getComputedStyle(candidate);
      const isGraphicLeaf =
        candidate.tagName === "SVG" ||
        candidate.tagName === "IMG" ||
        candidate.getAttribute("role") === "img" ||
        style.backgroundImage !== "none" ||
        style.maskImage !== "none" ||
        style.webkitMaskImage !== "none";

      if (!isGraphicLeaf) continue;

      candidate.style.setProperty("visibility", "hidden", "important");
      candidate.style.setProperty("pointer-events", "none", "important");
      candidate.setAttribute(HIDDEN_ATTR, "qwen-brand-graphic");
      hidden = true;
    }

    return hidden;
  }

  function hideBrandIconLeaves(container, textRect) {
    if (!(container instanceof HTMLElement)) return false;

    let hidden = false;
    const candidates = container.querySelectorAll("svg, img, [role='img'], *");

    for (const candidate of candidates) {
      if (!(candidate instanceof HTMLElement || candidate instanceof SVGElement)) continue;

      const rect = candidate.getBoundingClientRect();
      if (
        rect.width <= 0 ||
        rect.height <= 0 ||
        rect.width > 64 ||
        rect.height > 64 ||
        rect.top > 95 ||
        rect.left > textRect.left + 12 ||
        rect.right < textRect.left - 80 ||
        Math.abs((rect.top + rect.bottom) / 2 - (textRect.top + textRect.bottom) / 2) > 28
      ) {
        continue;
      }

      const style = window.getComputedStyle(candidate);
      const isImageLeaf =
        candidate.tagName === "SVG" ||
        candidate.tagName === "IMG" ||
        candidate.getAttribute("role") === "img" ||
        style.backgroundImage !== "none" ||
        style.maskImage !== "none" ||
        style.webkitMaskImage !== "none";

      if (!isImageLeaf) continue;

      candidate.style.setProperty("visibility", "hidden", "important");
      candidate.style.setProperty("pointer-events", "none", "important");
      candidate.setAttribute(HIDDEN_ATTR, "qwen-brand-icon");
      hidden = true;
    }

    return hidden;
  }

  function hideQwenBrandLeaves() {
    const nodes = document.querySelectorAll("span, div, a");

    for (const node of nodes) {
      if (!(node instanceof HTMLElement) || !isVisible(node)) continue;

      const rect = node.getBoundingClientRect();
      if (
        rect.top < -5 ||
        rect.top > 95 ||
        rect.left < -5 ||
        rect.left > 190 ||
        rect.width > 180 ||
        rect.height > 70
      ) {
        continue;
      }

      if (normalizeText(node.textContent).toLowerCase() !== "qwen") continue;
      if (!safelyHide(node, "qwen-brand-text")) continue;

      let container = node.parentElement;
      for (let depth = 0; container instanceof HTMLElement && depth < 4; depth += 1) {
        const containerRect = container.getBoundingClientRect();
        if (
          containerRect.top < -5 ||
          containerRect.top > 95 ||
          containerRect.left < -5 ||
          containerRect.left > 190 ||
          containerRect.width > 210 ||
          containerRect.height > 90
        ) {
          break;
        }

        hideBrandIconLeaves(container, rect);
        container = container.parentElement;
      }

      return true;
    }

    return false;
  }

  function customizePromptPlaceholder() {
    const controls = document.querySelectorAll("textarea, input, [contenteditable='true']");

    for (const control of controls) {
      if (!(control instanceof HTMLElement)) continue;

      const placeholder = normalizeText(control.getAttribute("placeholder"));
      if (placeholder.toLowerCase().includes("qwen")) {
        control.setAttribute("placeholder", "询问智能助手");
      }
    }
  }

  function makeLink(label, href, sameTab = false) {
    const link = document.createElement("a");
    link.textContent = label;
    link.href = href;
    link.target = sameTab ? "_self" : "_blank";
    link.rel = "noopener noreferrer";
    link.className = "ione-link";
    return link;
  }

  function mountToolbar() {
    if (document.getElementById(HOST_ID)) return;

    const host = document.createElement("div");
    host.id = HOST_ID;
    host.setAttribute("aria-label", "童健云智能助手快捷工具栏");
    const shadow = host.attachShadow({ mode: "open" });

    const style = document.createElement("style");
    style.textContent = `
      :host {
        all: initial;
        position: fixed;
        top: 10px;
        left: 50%;
        transform: translateX(-50%);
        z-index: 2147483646;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "PingFang SC",
          "Microsoft YaHei", sans-serif;
      }
      .bar {
        display: flex;
        align-items: center;
        gap: 8px;
        padding: 7px 9px;
        border: 1px solid rgba(15, 118, 110, .18);
        border-radius: 14px;
        background: rgba(255, 255, 255, .92);
        box-shadow: 0 8px 28px rgba(15, 23, 42, .12);
        backdrop-filter: blur(14px);
        -webkit-backdrop-filter: blur(14px);
        color: #0f172a;
        white-space: nowrap;
      }
      .brand {
        display: inline-flex;
        align-items: center;
        gap: 7px;
        padding: 0 4px;
        font-size: 13px;
        font-weight: 700;
      }
      .brand-dot {
        width: 9px;
        height: 9px;
        border-radius: 999px;
        background: #14b8a6;
        box-shadow: 0 0 0 4px rgba(20, 184, 166, .12);
      }
      .ione-link, .toggle {
        appearance: none;
        border: 0;
        border-radius: 9px;
        padding: 6px 9px;
        background: #f0fdfa;
        color: #0f766e;
        font: inherit;
        font-size: 12px;
        font-weight: 600;
        text-decoration: none;
        cursor: pointer;
      }
      .ione-link:hover, .toggle:hover {
        background: #ccfbf1;
      }
      .toggle {
        background: #f8fafc;
        color: #64748b;
      }
      .bar.compact .optional {
        display: none;
      }
      @media (prefers-color-scheme: dark) {
        .bar {
          background: rgba(15, 23, 42, .90);
          border-color: rgba(45, 212, 191, .22);
          color: #f8fafc;
          box-shadow: 0 8px 28px rgba(0, 0, 0, .28);
        }
        .ione-link {
          background: rgba(20, 184, 166, .14);
          color: #5eead4;
        }
        .ione-link:hover {
          background: rgba(20, 184, 166, .22);
        }
        .toggle {
          background: rgba(148, 163, 184, .12);
          color: #cbd5e1;
        }
      }
    `;

    const bar = document.createElement("nav");
    bar.className = "bar";

    const brand = document.createElement("span");
    brand.className = "brand";
    brand.innerHTML = '<span class="brand-dot"></span><span>童健云 · 智能助手</span>';

    const home = makeLink("返回童健云", `${SITE_ORIGIN}/desk`, true);
    home.classList.add("optional");

    const cockpit = makeLink("园长驾驶舱", `${SITE_ORIGIN}/app/director-dashboard`);
    cockpit.classList.add("optional");

    const refresh = document.createElement("button");
    refresh.type = "button";
    refresh.className = "toggle optional";
    refresh.textContent = "刷新页面";
    refresh.addEventListener("click", () => window.location.reload());

    const toggle = document.createElement("button");
    toggle.type = "button";
    toggle.className = "toggle";
    toggle.setAttribute("aria-label", "展开或收起童健云工具栏");

    const applyCompact = (compact) => {
      bar.classList.toggle("compact", compact);
      toggle.textContent = compact ? "展开" : "收起";
      try {
        window.localStorage.setItem(COMPACT_KEY, compact ? "1" : "0");
      } catch (_) {
        // Page customization still works if localStorage is unavailable.
      }
    };

    let compact = false;
    try {
      compact = window.localStorage.getItem(COMPACT_KEY) === "1";
    } catch (_) {
      compact = false;
    }

    toggle.addEventListener("click", () => applyCompact(!bar.classList.contains("compact")));

    bar.append(brand, home, cockpit, refresh, toggle);
    shadow.append(style, bar);
    document.documentElement.appendChild(host);
    applyCompact(compact);
  }

  function applySafeCustomization() {
    setPageTitle();
    mountToolbar();
    resetSafeHiddenNodes();
    mountBrandMask();
    hideQwenBrandLeaves();
    hideTopLeftBrandGraphicLeaves();
    hideTargetModelSelector();
    customizePromptPlaceholder();
  }

  restoreLegacyHiddenNodes();
  applySafeCustomization();

  window.setInterval(applySafeCustomization, 1200);

  const titleObserver = new MutationObserver(setPageTitle);
  if (document.head) {
    titleObserver.observe(document.head, {
      childList: true,
      subtree: true,
      characterData: true,
    });
  }
})();
