(() => {
  "use strict";

  const HOST_ID = "ione-qwen-companion-recovery-v210";
  const SITE_ORIGIN = "https://child.myyr.top";
  const LEGACY_MARKERS = [
    "data-ione-hidden",
    "data-ione-safe-hidden",
    "data-ione-v2-model-button",
    "data-ione-model-hidden",
    "data-ione-v202-hidden",
  ];

  function cleanupMarkedElement(element) {
    if (!(element instanceof HTMLElement || element instanceof SVGElement)) return;

    element.style.removeProperty("display");
    element.style.removeProperty("visibility");
    element.style.removeProperty("opacity");
    element.style.removeProperty("pointer-events");

    for (const marker of LEGACY_MARKERS) {
      element.removeAttribute(marker);
    }
  }

  function cleanupLegacyEffects() {
    document.getElementById("ione-qwen-brand-mask")?.remove();
    document.getElementById("ione-qwen-companion")?.remove();
    document.getElementById("ione-qwen-companion-v2")?.remove();

    const selector = LEGACY_MARKERS.map((marker) => `[${marker}]`).join(",");
    document.querySelectorAll(selector).forEach(cleanupMarkedElement);
  }

  function link(label, href, sameTab = false) {
    const node = document.createElement("a");
    node.textContent = label;
    node.href = href;
    node.target = sameTab ? "_self" : "_blank";
    node.rel = "noopener noreferrer";
    node.className = "ione-link";
    return node;
  }

  function mountRecoveryToolbar() {
    if (document.getElementById(HOST_ID)) return;

    const host = document.createElement("div");
    host.id = HOST_ID;
    const shadow = host.attachShadow({ mode: "open" });

    const style = document.createElement("style");
    style.textContent = `
      :host {
        all: initial;
        position: fixed;
        top: 10px;
        left: 50%;
        transform: translateX(-50%);
        z-index: 2147483647;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "PingFang SC",
          "Microsoft YaHei", sans-serif;
      }
      .bar {
        display: flex;
        align-items: center;
        gap: 8px;
        padding: 8px 10px;
        border: 1px solid rgba(220, 38, 38, .25);
        border-radius: 14px;
        background: rgba(255, 255, 255, .96);
        box-shadow: 0 8px 28px rgba(15, 23, 42, .16);
        color: #111827;
        white-space: nowrap;
      }
      .badge {
        padding: 3px 7px;
        border-radius: 7px;
        background: #fee2e2;
        color: #b91c1c;
        font-size: 11px;
        font-weight: 800;
      }
      .brand {
        font-size: 13px;
        font-weight: 800;
      }
      .ione-link, button {
        appearance: none;
        border: 0;
        border-radius: 9px;
        padding: 6px 9px;
        background: #f3f4f6;
        color: #374151;
        font: inherit;
        font-size: 12px;
        font-weight: 600;
        text-decoration: none;
        cursor: pointer;
      }
    `;

    const bar = document.createElement("nav");
    bar.className = "bar";

    const badge = document.createElement("span");
    badge.className = "badge";
    badge.textContent = "恢复版 v2.1.0";

    const brand = document.createElement("span");
    brand.className = "brand";
    brand.textContent = "童健云 · 智能助手";

    const home = link("返回童健云", `${SITE_ORIGIN}/desk`, true);

    const refresh = document.createElement("button");
    refresh.type = "button";
    refresh.textContent = "刷新 Qwen";
    refresh.addEventListener("click", () => window.location.reload());

    bar.append(badge, brand, home, refresh);
    shadow.append(style, bar);
    document.documentElement.appendChild(host);
  }

  cleanupLegacyEffects();
  mountRecoveryToolbar();

  // If an older extension instance is still active, it may write one of the
  // legacy marker attributes again. Only observe those private markers and
  // immediately undo their styles. This does not inspect chat content.
  const observer = new MutationObserver((mutations) => {
    for (const mutation of mutations) {
      if (!(mutation.target instanceof Element)) continue;
      if (!LEGACY_MARKERS.includes(mutation.attributeName || "")) continue;
      cleanupMarkedElement(mutation.target);
    }
  });

  observer.observe(document.documentElement, {
    subtree: true,
    attributes: true,
    attributeFilter: LEGACY_MARKERS,
  });
})();
