(() => {
  "use strict";

  const HOST_ID = "ione-qwen-companion";
  const SITE_ORIGIN = "https://child.myyr.top";
  const COMPACT_KEY = "ione_qwen_companion_compact";
  const BRAND_TITLE = "童健云 · 智能助手 · Qwen";

  function setPageTitle() {
    if (document.title !== BRAND_TITLE) {
      document.title = BRAND_TITLE;
    }
  }

  function makeLink(label, href, sameTab = false) {
    const link = document.createElement("a");
    link.textContent = label;
    link.href = href;
    link.target = sameTab ? "_self" : "_blank";
    link.rel = "noopener noreferrer";
    link.className = "ione-link";
    return link;
  }

  function mountToolbar() {
    if (document.getElementById(HOST_ID)) return;

    const host = document.createElement("div");
    host.id = HOST_ID;
    host.setAttribute("aria-label", "童健云 Qwen 快捷工具栏");
    const shadow = host.attachShadow({ mode: "open" });

    const style = document.createElement("style");
    style.textContent = `
      :host {
        all: initial;
        position: fixed;
        top: 10px;
        left: 50%;
        transform: translateX(-50%);
        z-index: 2147483646;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "PingFang SC",
          "Microsoft YaHei", sans-serif;
      }
      .bar {
        display: flex;
        align-items: center;
        gap: 8px;
        padding: 7px 9px;
        border: 1px solid rgba(15, 118, 110, .18);
        border-radius: 14px;
        background: rgba(255, 255, 255, .92);
        box-shadow: 0 8px 28px rgba(15, 23, 42, .12);
        backdrop-filter: blur(14px);
        -webkit-backdrop-filter: blur(14px);
        color: #0f172a;
        white-space: nowrap;
      }
      .brand {
        display: inline-flex;
        align-items: center;
        gap: 7px;
        padding: 0 4px;
        font-size: 13px;
        font-weight: 700;
      }
      .brand-dot {
        width: 9px;
        height: 9px;
        border-radius: 999px;
        background: #14b8a6;
        box-shadow: 0 0 0 4px rgba(20, 184, 166, .12);
      }
      .ione-link, .toggle {
        appearance: none;
        border: 0;
        border-radius: 9px;
        padding: 6px 9px;
        background: #f0fdfa;
        color: #0f766e;
        font: inherit;
        font-size: 12px;
        font-weight: 600;
        text-decoration: none;
        cursor: pointer;
      }
      .ione-link:hover, .toggle:hover {
        background: #ccfbf1;
      }
      .toggle {
        background: #f8fafc;
        color: #64748b;
      }
      .bar.compact .optional {
        display: none;
      }
      @media (prefers-color-scheme: dark) {
        .bar {
          background: rgba(15, 23, 42, .90);
          border-color: rgba(45, 212, 191, .22);
          color: #f8fafc;
          box-shadow: 0 8px 28px rgba(0, 0, 0, .28);
        }
        .ione-link {
          background: rgba(20, 184, 166, .14);
          color: #5eead4;
        }
        .ione-link:hover {
          background: rgba(20, 184, 166, .22);
        }
        .toggle {
          background: rgba(148, 163, 184, .12);
          color: #cbd5e1;
        }
      }
    `;

    const bar = document.createElement("nav");
    bar.className = "bar";

    const brand = document.createElement("span");
    brand.className = "brand";
    brand.innerHTML = '<span class="brand-dot"></span><span>童健云 · Qwen</span>';

    const home = makeLink("返回童健云", `${SITE_ORIGIN}/desk`, true);
    home.classList.add("optional");

    const cockpit = makeLink("园长驾驶舱", `${SITE_ORIGIN}/app/director-dashboard`);
    cockpit.classList.add("optional");

    const refresh = document.createElement("button");
    refresh.type = "button";
    refresh.className = "toggle optional";
    refresh.textContent = "刷新 Qwen";
    refresh.addEventListener("click", () => window.location.reload());

    const toggle = document.createElement("button");
    toggle.type = "button";
    toggle.className = "toggle";
    toggle.setAttribute("aria-label", "展开或收起童健云工具栏");

    const applyCompact = (compact) => {
      bar.classList.toggle("compact", compact);
      toggle.textContent = compact ? "展开" : "收起";
      try {
        window.localStorage.setItem(COMPACT_KEY, compact ? "1" : "0");
      } catch (_) {
        // Qwen can still be used if localStorage is unavailable.
      }
    };

    let compact = false;
    try {
      compact = window.localStorage.getItem(COMPACT_KEY) === "1";
    } catch (_) {
      compact = false;
    }
    toggle.addEventListener("click", () => applyCompact(!bar.classList.contains("compact")));

    bar.append(brand, home, cockpit, refresh, toggle);
    shadow.append(style, bar);
    document.documentElement.appendChild(host);
    applyCompact(compact);
  }

  function initialize() {
    setPageTitle();
    mountToolbar();
  }

  initialize();

  const titleObserver = new MutationObserver(setPageTitle);
  if (document.head) {
    titleObserver.observe(document.head, {
      childList: true,
      subtree: true,
      characterData: true,
    });
  }
})();
