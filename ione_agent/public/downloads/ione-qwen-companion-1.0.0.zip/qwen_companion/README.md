# 童健云 Qwen 智能助手浏览器扩展

这个扩展只在 `https://chat.qwen.ai/*` 生效，用于把 Qwen 网页作为童健云的“智能助手”入口。

## 能力

- 保留 Qwen 原生网页登录流程；不保存账号密码。
- 不申请 `cookies`、`tabs`、`webRequest` 等敏感浏览器权限。
- 不读取、上传或转发聊天内容。
- 把浏览器标签标题改为“童健云 · 智能助手 · Qwen”。
- 增加浮动工具栏：返回童健云、园长驾驶舱、刷新 Qwen、收起/展开。
- 不删除 Qwen 品牌、来源标识或输出标识。

## 自动登录方式

扩展本身不注入 Cookie，也不填写密码。第一次在当前 Edge/Chrome Profile 中正常登录 Qwen 后，
浏览器会按 Qwen 自身的会话策略保存登录状态。以后从童健云点击“智能助手”打开
`chat.qwen.ai` 时，会自然复用同一浏览器 Profile 的登录会话。

如果 Qwen 主动要求重新登录，需要按 Qwen 正常流程重新认证一次。

## Edge 安装

1. 解压扩展 ZIP。
2. 打开 `edge://extensions/`。
3. 开启“开发人员模式”。
4. 点击“加载解压缩的扩展”。
5. 选择包含 `manifest.json` 的 `qwen_companion` 目录。
6. 刷新已打开的 Qwen 页面。

## Chrome 安装

1. 解压扩展 ZIP。
2. 打开 `chrome://extensions/`。
3. 开启“开发者模式”。
4. 点击“加载已解压的扩展程序”。
5. 选择包含 `manifest.json` 的 `qwen_companion` 目录。

## 安全边界

此版本只做启动入口和本地页面显示定制，不实现自动发送消息、抓取回复、Cookie 导出或 MCP 自动执行。
