# 童健云智能助手浏览器扩展

此扩展只在 `https://chat.qwen.ai/*` 生效。

## 1.1.5

- 根据 Qwen 当前真实 DOM 精确隐藏品牌 Logo：
  `img.logo-img[alt="logo"]` 且 `src` 包含 `qwen-logo.svg`。
- 删除 1.1.4 的左上区域遮罩。
- 删除基于位置、SVG/CSS 图形扫描的品牌隐藏逻辑。
- 页面升级后会主动清理旧版残留的 `#ione-qwen-brand-mask`。
- 保留 Qwen3.8-Max 模型按钮隐藏、输入提示替换和 SPA 对话切换修复。
- 不读取 Cookie、密码或聊天内容，不自动切换模型。

## 升级

1. 下载并解压 1.1.5 ZIP。
2. 打开 `edge://extensions/`。
3. 删除旧版，或覆盖旧目录后点击“重新加载”。
4. 加载新版 `qwen_companion` 目录。
5. 回到 Qwen 页面按 `Ctrl+F5`。
