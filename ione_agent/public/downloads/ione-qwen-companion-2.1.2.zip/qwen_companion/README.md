# 童健云智能助手 2.1.2

基于 2.1.1，只修复模型选择器的精确隐藏时机。

## 模型选择区

隐藏条件：

- 元素必须是 `div.wms-trigger__content`
- 直接子元素必须有 `div.wms-trigger__text`
- 文本必须严格等于 `Qwen3.8-Max`
- 直接子元素必须有 `span.wms-trigger__icon`

2.1.2 删除了所有屏幕坐标和尺寸限制。Qwen SPA 如果先挂载外层、后挂载文字或图标，新增子节点时会通过 `closest("div.wms-trigger__content")` 回查当前精确模型容器，再执行隐藏。

只隐藏这个 `.wms-trigger__content` 自身，不隐藏任何父容器。

Logo 继续只匹配真实 `qwen-logo.svg` 图片。

保留 2.1.0 的旧版副作用恢复逻辑。
