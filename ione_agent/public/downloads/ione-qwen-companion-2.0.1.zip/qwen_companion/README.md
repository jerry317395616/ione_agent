# 童健云智能助手浏览器扩展 2.0.1

2.0.1 使用你提供的 Qwen 真实 DOM 做精确静态隐藏。

- Logo：`img.logo-img[alt="logo"][src*="qwen-logo.svg"]`
- 模型选择区：`.wms-trigger__content`
- 模型区包含 `.wms-trigger__text` 的 `Qwen3.8-Max` 和下拉箭头，一并隐藏。
- 两处都只使用静态 CSS，不执行 DOM 轮询。
- 不使用 MutationObserver。
- 不扫描或隐藏父容器。
- 不影响新建对话、历史对话和聊天主体。
- 顶部工具栏显示 `v2.0.1`，用于确认实际加载版本。

升级时请先在 edge://extensions/ 删除所有旧的“童健云智能助手”实例，只保留 2.0.1。
